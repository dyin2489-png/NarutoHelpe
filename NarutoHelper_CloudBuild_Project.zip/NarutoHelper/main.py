__version__ = "1.0.0"

import json
import os
import time
from datetime import datetime

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView


class NarutoHelper(App):
    def build(self):
        self.title = "忍者辅助面板"
        self.elapsed = 0.0
        self.match_running = False
        self.match_started_at = None
        self.cooldowns = {}
        self.events = []

        Window.clearcolor = (0.07, 0.09, 0.13, 1)

        root = BoxLayout(
            orientation="vertical",
            padding=dp(12),
            spacing=dp(8)
        )

        root.add_widget(Label(
            text="[b]忍者辅助面板[/b]",
            markup=True,
            font_size="23sp",
            size_hint_y=None,
            height=dp(44)
        ))

        self.match_label = Label(
            text="对局计时 00:00",
            font_size="22sp",
            size_hint_y=None,
            height=dp(42)
        )
        root.add_widget(self.match_label)

        row = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(8))
        self.add_btn(row, "开始 / 暂停", self.toggle_match)
        self.add_btn(row, "重置", self.reset_match)
        root.add_widget(row)

        root.add_widget(Label(
            text="冷却秒数（1–3600）",
            size_hint_y=None, height=dp(26)
        ))

        self.seconds_input = TextInput(
            text="15", hint_text="秒数", input_filter="int",
            multiline=False, size_hint_y=None, height=dp(44)
        )
        root.add_widget(self.seconds_input)

        self.skill_input = TextInput(
            text="替身术", hint_text="事件名称", multiline=False,
            size_hint_y=None, height=dp(44)
        )
        root.add_widget(self.skill_input)

        row2 = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(8))
        self.add_btn(row2, "开始倒计时", self.start_cooldown)
        self.add_btn(row2, "清除计时", self.clear_cooldowns)
        root.add_widget(row2)

        self.cooldown_label = Label(
            text="当前倒计时：无",
            size_hint_y=None, height=dp(54)
        )
        root.add_widget(self.cooldown_label)

        self.note_input = TextInput(
            hint_text="输入个人备注", multiline=False,
            size_hint_y=None, height=dp(44)
        )
        root.add_widget(self.note_input)
        self.add_btn(root, "保存备注", self.save_note)

        root.add_widget(Label(
            text="事件记录", size_hint_y=None, height=dp(28)
        ))

        scroll = ScrollView()
        self.log_label = Label(
            text="暂无记录", size_hint_y=None,
            halign="left", valign="top"
        )
        self.log_label.bind(texture_size=self.update_log_height)
        scroll.add_widget(self.log_label)
        root.add_widget(scroll)

        self.load_events()
        self.refresh_log()
        Clock.schedule_interval(self.tick, 0.25)
        return root

    def add_btn(self, parent, text, callback):
        btn = Button(text=text, size_hint_y=None, height=dp(46))
        btn.bind(on_release=lambda *_: callback())
        parent.add_widget(btn)

    def toggle_match(self):
        if self.match_running:
            self.elapsed += time.monotonic() - self.match_started_at
            self.match_running = False
            self.record("对局计时已暂停")
        else:
            self.match_started_at = time.monotonic()
            self.match_running = True
            self.record("对局计时已开始")

    def reset_match(self):
        self.elapsed = 0.0
        if self.match_running:
            self.match_started_at = time.monotonic()
        self.record("对局计时已重置")

    def start_cooldown(self):
        name = self.skill_input.text.strip() or "自定义事件"
        try:
            seconds = int(self.seconds_input.text)
            if not 1 <= seconds <= 3600:
                raise ValueError
        except ValueError:
            self.record("请输入 1 到 3600 之间的秒数")
            return
        self.cooldowns[name] = time.monotonic() + seconds
        self.record(f"{name}：开始 {seconds} 秒倒计时")

    def clear_cooldowns(self):
        self.cooldowns.clear()
        self.record("已清除所有倒计时")

    def save_note(self):
        note = self.note_input.text.strip()
        if note:
            self.record("备注：" + note)
            self.note_input.text = ""

    def record(self, message):
        stamp = datetime.now().strftime("%H:%M:%S")
        self.events.insert(0, f"[{stamp}] {message}")
        self.events = self.events[:100]
        self.refresh_log()
        self.save_events()

    def tick(self, _dt):
        total = self.elapsed
        if self.match_running:
            total += time.monotonic() - self.match_started_at

        minutes, seconds = divmod(int(total), 60)
        self.match_label.text = f"对局计时 {minutes:02d}:{seconds:02d}"

        now = time.monotonic()
        remaining = {
            name: max(0, int(deadline - now + 0.999))
            for name, deadline in self.cooldowns.items()
        }

        expired = [
            name for name, deadline in self.cooldowns.items()
            if now >= deadline
        ]
        for name in expired:
            del self.cooldowns[name]
            self.record(f"{name}：倒计时结束")

        if remaining:
            self.cooldown_label.text = "当前倒计时：\n" + " | ".join(
                f"{name} {sec}s" for name, sec in remaining.items()
                if sec > 0
            )
            if not self.cooldowns:
                self.cooldown_label.text = "当前倒计时：无"
        else:
            self.cooldown_label.text = "当前倒计时：无"

    def update_log_height(self, instance, size):
        instance.height = size[1]
        instance.text_size = (max(0, instance.width), None)

    def refresh_log(self):
        self.log_label.text = "\n".join(self.events) or "暂无记录"

    def data_path(self):
        return os.path.join(self.user_data_dir, "events.json")

    def save_events(self):
        try:
            os.makedirs(self.user_data_dir, exist_ok=True)
            with open(self.data_path(), "w", encoding="utf-8") as f:
                json.dump(self.events, f, ensure_ascii=False)
        except OSError:
            pass

    def load_events(self):
        try:
            with open(self.data_path(), "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                self.events = [str(item) for item in data[:100]]
        except (OSError, ValueError, TypeError):
            self.events = []


if __name__ == "__main__":
    NarutoHelper().run()
