# 忍者辅助面板（Android / Python）

这是一个独立的 Kivy 辅助计时应用原型，提供：
- 对局计时（开始、暂停、重置）
- 自定义事件/技能倒计时
- 手动备注与最近 100 条事件记录
- 本地保存记录

它不读取《火影忍者》手游内存、不注入游戏进程、不识别敌人位置，也不包含跨应用悬浮窗功能。

## 项目文件
- `main.py`：应用代码
- `buildozer.spec`：Android APK 构建配置

## 构建环境
建议使用 Ubuntu 24.04 或 WSL2 + Ubuntu。首次构建需要网络下载 Android SDK/NDK 组件。

安装系统依赖（如发行版或 Buildozer 版本不同，请参考 Buildozer 官方文档调整）：

```bash
sudo apt update
sudo apt install -y git zip unzip openjdk-17-jdk \
  python3-pip python3-venv python3-dev \
  build-essential autoconf libtool pkg-config \
  zlib1g-dev libncurses-dev cmake libffi-dev \
  libssl-dev automake
```

创建虚拟环境并安装 Buildozer：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install buildozer
```

在项目根目录运行：

```bash
buildozer android debug
```

首次构建可能需要较长时间。成功后 APK 会生成在 `bin/` 目录。

## 安装到手机
将 `bin/` 中的 APK 复制到 Android 手机，允许文件管理器安装未知应用后安装即可。

## 说明
- `package.domain = org.example` 是占位值，正式发布前应替换为你自己的反向域名。
- 本项目当前配置为 `arm64-v8a`。如需支持其他架构，可在 `buildozer.spec` 中调整 `android.archs`。
- 本项目是可构建的源码项目，不是已经编译签名的 APK。


## 云端自动构建 APK（不需要在手机上安装编译环境）

项目已附带 `.github/workflows/build-apk.yml`。可使用 GitHub Actions 在云端构建 APK：

1. 在 GitHub 新建一个仓库。
2. 将此项目中的所有文件上传到仓库，确保 `.github/workflows/build-apk.yml` 也被上传。
3. 打开仓库的 **Actions** 页面，选择 **Build Android APK**。
4. 点击 **Run workflow** 并等待构建完成。
5. 打开成功的运行记录，在 **Artifacts** 区域下载 `NarutoHelper-Android-APK`。
6. 解压 Artifact，取得 `.apk` 文件后传到安卓手机安装。

首次构建需要下载 Android 构建工具，因此通常会花一些时间。GitHub 账户、仓库和 Actions 的可用性及配额以 GitHub 当前政策为准。此工作流产出的是 debug APK，不是用于商店发布的正式签名版本。
