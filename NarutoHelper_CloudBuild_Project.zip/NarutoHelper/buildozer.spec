[app]

title = Naruto Helper
package.name = narutohelper
package.domain = org.example
source.dir = .
source.include_exts = py,json,png,jpg,kv,md
version = 1.0.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0

# This first version does not request network, overlay, or game-access permissions.
# It is a standalone companion app, not an in-game overlay.

android.api = 35
android.minapi = 23
android.archs = arm64-v8a

[buildozer]
log_level = 2
warn_on_root = 1
